#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Compose the 苏南后勤集团 2026 小雪 WeChat long image.

Visual language borrowed from the reference poster (light-blue snowy paper,
red plum, white calligraphy 小雪, vermilion wall and Chinese eaves) but newly
composed. No 千图 watermark, no phone numbers, no 2025 date, no lunar date.
Copy is taken verbatim from ARTICLE_TEXT.txt (verified cultural content).
Brand appears only as typographic signature, no invented logo.
"""
from __future__ import annotations

from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path("/workspace/sunan-xiaoxue-customs-2026")
ASSETS = ROOT / "assets"
SEGMENTS = ROOT / "segments"
OUT_JPG = ROOT / "长图-苏南后勤集团-小雪节气.jpg"
OUT_PNG = ROOT / "长图-苏南后勤集团-小雪节气.png"
CALLIGRAPHY = ROOT / "assets" / "calligraphy.jpg"
ARTICLE = (ROOT / "ARTICLE_TEXT.txt").read_text(encoding="utf-8")

REQUIRED = [
    "01-hero-sky-plum-eaves.png",
    "02-still-cured.png",
    "03-still-ciaba.png",
    "04-ending-eaves-snow.png",
]

W = 1080
# Palette sampled from the reference atmosphere, not its typography
SKY_DEEP = (48, 112, 178)
SKY_MID = (120, 176, 216)
SKY_PALE = (210, 230, 246)
PAPER = (232, 242, 250)
INK = (28, 44, 68)
INK_SOFT = (70, 96, 128)
WHITE = (252, 252, 252)
VERMILION = (206, 46, 36)
GOLD_CREAM = (245, 232, 214)

SANS_R = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
SANS_B = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
SERIF_R = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc"
SERIF_B = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"
WENKAI_L = "/home/box/.fonts/lxgw-wenkai-v1.520/LXGWWenKai-Light.ttf"
WENKAI_R = "/home/box/.fonts/lxgw-wenkai-v1.520/LXGWWenKai-Regular.ttf"
WENKAI_M = "/home/box/.fonts/lxgw-wenkai-v1.520/LXGWWenKai-Medium.ttf"
EN_SANS = "/usr/share/fonts/truetype/sand-box/google/Inria Sans/InriaSans-Light.ttf"
SC = 2

MARGIN = 100
TEXT_W = W - MARGIN * 2


def fnt(path, size, index=None):
    if index is None:
        return ImageFont.truetype(path, size)
    return ImageFont.truetype(path, size, index=index)


def f_wk(size, w="R"):
    return fnt({"L": WENKAI_L, "R": WENKAI_R, "M": WENKAI_M}[w], size)


def f_serif(size, bold=False):
    return fnt(SERIF_B if bold else SERIF_R, size, SC)


def f_sans(size, bold=False):
    return fnt(SANS_B if bold else SANS_R, size, SC)


def f_en(size):
    return fnt(EN_SANS, size)


def ink_cutout(path: Path, threshold: int = 210) -> Image.Image:
    im = Image.open(path).convert("RGBA")
    arr = np.array(im).astype(np.float32)
    luma = 0.299 * arr[:, :, 0] + 0.587 * arr[:, :, 1] + 0.114 * arr[:, :, 2]
    alpha = np.clip((threshold - luma) * (255.0 / 90.0), 0, 255)
    ys, xs = np.where(alpha > 12)
    if len(xs) == 0:
        arr[:, :, 3] = alpha
        return Image.fromarray(arr.astype(np.uint8), "RGBA")
    pad = 16
    x0, x1 = max(0, int(xs.min()) - pad), min(arr.shape[1], int(xs.max()) + pad)
    y0, y1 = max(0, int(ys.min()) - pad), min(arr.shape[0], int(ys.max()) + pad)
    arr = arr[y0:y1, x0:x1]
    luma = luma[y0:y1, x0:x1]
    alpha = np.clip((threshold - luma) * (255.0 / 90.0), 0, 255)
    # white brush, slightly warm
    arr[:, :, 0] = 252
    arr[:, :, 1] = 252
    arr[:, :, 2] = 250
    arr[:, :, 3] = alpha
    return Image.fromarray(arr.astype(np.uint8), "RGBA")


def paper_block(h, color=PAPER):
    return Image.new("RGB", (W, max(1, int(h))), color)


def add_snow(im: Image.Image, n=280, seed=20261122) -> Image.Image:
    arr = np.array(im).convert("RGB") if False else np.array(im.convert("RGB"))
    rng = np.random.default_rng(seed)
    h, w = arr.shape[:2]
    xs = rng.integers(0, w, n)
    ys = rng.integers(0, h, n)
    rs = rng.integers(1, 3, n)
    for x, y, r in zip(xs, ys, rs):
        y0, y1 = max(0, y - r), min(h, y + r + 1)
        x0, x1 = max(0, x - r), min(w, x + r + 1)
        arr[y0:y1, x0:x1] = np.clip(arr[y0:y1, x0:x1].astype(np.int16) + 28, 0, 255)
    return Image.fromarray(arr.astype(np.uint8), "RGB")


def vertical_gradient(h, c0=SKY_PALE, c1=PAPER) -> Image.Image:
    arr = np.zeros((h, W, 3), dtype=np.uint8)
    for i in range(h):
        t = i / max(1, h - 1)
        arr[i] = [int(c0[k] * (1 - t) + c1[k] * t) for k in range(3)]
    return Image.fromarray(arr, "RGB")


def fade_edges(im: Image.Image, into, side="bottom", frac=0.22) -> Image.Image:
    im = im.convert("RGBA")
    w, h = im.size
    arr = np.array(im).astype(np.float32)
    n = max(2, int((h if side in ("top", "bottom") else w) * frac))
    if side == "bottom":
        for i, y in enumerate(range(h - n, h)):
            arr[y, :, 3] *= 1 - (i / (n - 1)) ** 1.15
    elif side == "top":
        for i, y in enumerate(range(0, n)):
            arr[y, :, 3] *= 1 - ((n - 1 - i) / (n - 1)) ** 1.15
    base = Image.new("RGBA", (w, h), into + (255,))
    return Image.alpha_composite(base, Image.fromarray(arr.astype(np.uint8), "RGBA")).convert("RGB")


def scale_to_width(im, width):
    h = int(im.height * width / im.width)
    return im.resize((width, h), Image.Resampling.LANCZOS)


def skyish_background_color(arr: np.ndarray) -> np.ndarray:
    """Estimate pale sky/paper color from the border, ignoring plum or props."""
    h, w = arr.shape[:2]
    b = max(12, min(h, w) // 18)
    border = np.concatenate([
        arr[:b].reshape(-1, 3),
        arr[-b:].reshape(-1, 3),
        arr[:, :b].reshape(-1, 3),
        arr[:, -b:].reshape(-1, 3),
    ], axis=0)
    luma = 0.299 * border[:, 0] + 0.587 * border[:, 1] + 0.114 * border[:, 2]
    sat = border.max(axis=1) - border.min(axis=1)
    mask = (luma > 160) & (sat < 70)
    sample = border[mask] if int(mask.sum()) > 30 else border
    return np.median(sample, axis=0)


def blend_spot_to_paper(im: Image.Image, target=PAPER, edge=64) -> Image.Image:
    im = im.convert("RGB")
    arr = np.array(im).astype(np.float32)
    src = skyish_background_color(arr)
    dist = np.linalg.norm(arr - src[None, None, :], axis=2)
    # generous tolerance so textured pale-blue washes dissolve into the paper
    alpha = np.clip((dist - 16.0) / 48.0, 0.0, 1.0)
    bg = np.array(target, dtype=np.float32)[None, None, :]
    blended = arr * alpha[:, :, None] + bg * (1.0 - alpha[:, :, None])
    h, w = arr.shape[:2]
    ef = min(edge, h // 5, w // 5)
    if ef > 2:
        wy = np.ones(h, dtype=np.float32)
        wx = np.ones(w, dtype=np.float32)
        ramp = np.linspace(0.0, 1.0, ef, dtype=np.float32) ** 0.85
        wy[:ef] = ramp
        wy[-ef:] = ramp[::-1]
        wx[:ef] = ramp
        wx[-ef:] = ramp[::-1]
        mask = wy[:, None] * wx[None, :]
        blended = blended * mask[:, :, None] + bg * (1.0 - mask[:, :, None])
    return Image.fromarray(np.clip(blended, 0, 255).astype(np.uint8), "RGB")


def trim_spot(path: Path, max_w: int, max_h: int, paper=PAPER) -> Image.Image:
    im = blend_spot_to_paper(Image.open(path), paper)
    arr = np.array(im).astype(np.float32)
    diff = np.linalg.norm(arr - np.array(paper, dtype=np.float32)[None, None, :], axis=2)
    ys, xs = np.where(diff > 8.0)
    if len(xs):
        pad = 18
        im = im.crop((
            max(0, int(xs.min()) - pad),
            max(0, int(ys.min()) - pad),
            min(im.width, int(xs.max()) + pad),
            min(im.height, int(ys.max()) + pad),
        ))
    scale = min(max_w / im.width, max_h / im.height)
    return im.resize((max(1, int(im.width * scale)), max(1, int(im.height * scale))), Image.Resampling.LANCZOS)


KEEP_TOGETHER = {
    "太阳", "节气", "小雪", "各地", "北方", "南方", "天气", "地气",
    "彩虹", "古人", "时令", "文献", "腊味", "入冬", "鱼干", "糍粑",
    "团圆", "御冬", "闭塞", "不见", "交会", "闭藏", "由来", "三候",
    "黄经", "降水", "气温", "初雪", "雪量", "水汽",
}


def wrap_cjk(text, font, max_w):
    hang = set("，。、；：！？,.!?;:”’）】》」")
    lines, cur = [], ""
    dummy = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    for ch in text:
        trial = cur + ch
        w = dummy.textbbox((0, 0), trial, font=font)[2]
        if w <= max_w or not cur:
            cur = trial
        else:
            if ch in hang and cur:
                cur = trial
                lines.append(cur)
                cur = ""
            else:
                lines.append(cur)
                cur = ch
    if cur:
        lines.append(cur)
    # don't split common two-character words across a line break
    i = 0
    while i < len(lines) - 1:
        if lines[i] and lines[i + 1] and (lines[i][-1] + lines[i + 1][0]) in KEEP_TOGETHER:
            lines[i + 1] = lines[i][-1] + lines[i + 1]
            lines[i] = lines[i][:-1]
            if not lines[i]:
                lines.pop(i)
                continue
        i += 1
    return [ln for ln in lines if ln]


def draw_paras(draw, paras, x, y, max_w, font, fill, line_h, para_gap):
    for i, p in enumerate(paras):
        for line in wrap_cjk(p, font, max_w):
            draw.text((x, y), line, font=font, fill=fill)
            y += line_h
        if i < len(paras) - 1:
            y += para_gap
    return y


def measure_paras(paras, font, max_w, line_h, para_gap):
    h = 0
    for i, p in enumerate(paras):
        h += len(wrap_cjk(p, font, max_w)) * line_h
        if i < len(paras) - 1:
            h += para_gap
    return h


def draw_tracked(draw, xy, text, font, fill, tracking=6):
    x, y = xy
    for i, ch in enumerate(text):
        draw.text((x, y), ch, font=font, fill=fill)
        x += draw.textbbox((0, 0), ch, font=font)[2] + (tracking if i < len(text) - 1 else 0)
    return x


def require_assets():
    missing = [n for n in REQUIRED if not (ASSETS / n).exists()]
    if not CALLIGRAPHY.exists():
        missing.append(str(CALLIGRAPHY))
    if missing:
        raise SystemExit("Missing assets, nothing written:\n  " + "\n  ".join(missing))


def make_cover() -> Image.Image:
    hero = Image.open(ASSETS / "01-hero-sky-plum-eaves.png").convert("RGB")
    hero = scale_to_width(hero, W)
    # Prefer a tall cover around 1920; crop to keep sky + eaves
    target = 1920
    if hero.height > target:
        # keep some top plum and the bottom eaves
        overflow = hero.height - target
        top = int(overflow * 0.22)
        hero = hero.crop((0, top, W, top + target))
    elif hero.height < 1680:
        # pad pale sky at top if the model returned a short image
        pad = 1680 - hero.height
        top_col = tuple(int(x) for x in np.median(np.array(hero)[:8].reshape(-1, 3), axis=0))
        canvas = Image.new("RGB", (W, 1680), SKY_DEEP)
        canvas.paste(vertical_gradient(pad, SKY_DEEP, top_col), (0, 0))
        canvas.paste(hero, (0, pad))
        hero = canvas

    cover = fade_edges(hero, PAPER, "bottom", 0.16)
    cover = cover.convert("RGBA")

    calli = ink_cutout(CALLIGRAPHY)
    cw = 360
    ch = int(calli.height * cw / calli.width)
    calli = calli.resize((cw, ch), Image.Resampling.LANCZOS)
    # drop shadow for readability on mid-blue
    shadow = calli.copy()
    sarr = np.array(shadow)
    sarr[:, :, 0:3] = 20
    sarr[:, :, 3] = (sarr[:, :, 3].astype(np.float32) * 0.28).astype(np.uint8)
    shadow = Image.fromarray(sarr, "RGBA").filter(ImageFilter.GaussianBlur(4))
    cx = (W - cw) // 2
    cy = int(cover.height * 0.28)
    cover.paste(shadow, (cx + 3, cy + 5), shadow)
    cover.paste(calli, (cx, cy), calli)

    cover = cover.convert("RGB")
    d = ImageDraw.Draw(cover)
    # MINOR SNOW + date, centered under calligraphy
    sub_y = cy + ch + 18
    label = "MINOR SNOW"
    f_label = f_en(22)
    tw = d.textbbox((0, 0), label, font=f_label)[2]
    d.text(((W - tw) // 2, sub_y), label, font=f_label, fill=WHITE)
    # thin hairline
    mid = W // 2
    d.rectangle([mid - 36, sub_y + 36, mid + 36, sub_y + 38], fill=WHITE)
    date = "2026年11月22日"
    f_date = f_wk(24, "L")
    tw = d.textbbox((0, 0), date, font=f_date)[2]
    dy = sub_y + 52
    d.text(((W - tw) // 2 + 1, dy + 1), date, font=f_date, fill=(30, 50, 80))
    d.text(((W - tw) // 2, dy), date, font=f_date, fill=WHITE)

    # typographic signature under the date, in the open sky; no invented logo
    org = "苏南后勤集团"
    f_org = f_wk(22, "L")
    tw = d.textbbox((0, 0), org, font=f_org)[2]
    oy = dy + 46
    d.text(((W - tw) // 2 + 1, oy + 1), org, font=f_org, fill=(30, 50, 80))
    d.text(((W - tw) // 2, oy), org, font=f_org, fill=WHITE)
    return cover


def make_origin() -> Image.Image:
    f_h = f_serif(40)
    f_body = f_wk(30, "R")
    paras = [
        "小雪到了。",
        "它是二十四节气里的第二十个节气，也是冬季的第二个节气。当太阳到达黄经240°，便进入小雪。",
        "小雪主要反映的是降水和气温的变化：天气更冷，水汽也更容易由雨转成雪。但节气的名字，并不代表这一天各地都会下雪。北方有的地方可能迎来初雪，雪量往往还不大；许多南方地方，也许只是更冷、更干一些。同一节气，景象并不相同。",
    ]
    text_h = measure_paras(paras, f_body, TEXT_W, 58, 36)
    H = 160 + text_h + 80
    im = vertical_gradient(H, PAPER, PAPER)
    im = add_snow(im, n=90, seed=11)
    d = ImageDraw.Draw(im)
    d.rectangle([MARGIN, 36, W - MARGIN, 37], fill=(190, 214, 230))
    d.text((MARGIN, 60), "小雪由来", font=f_h, fill=INK)
    d.rectangle([MARGIN, 118, MARGIN + 64, 122], fill=VERMILION)
    draw_paras(d, paras, MARGIN, 150, TEXT_W, f_body, INK, 58, 36)
    return im


def make_hou() -> Image.Image:
    f_h = f_serif(40)
    f_body = f_wk(30, "R")
    f_item = f_wk(30, "M")
    intro = [
        "古人把一个节气大约十五天分成三候，用来观察时令的变化。这是古人对季节的体会，不是今天的天气预报。",
    ]
    items = [
        ("一候「虹藏不见」", "天冷之后，彩虹不再常见。"),
        ("二候「天气上升地气下降」", "古人认为，此时天气上升、地气下降，天地之气不再交会。"),
        ("三候「闭塞而成冬」", "气息闭藏，冬天的意味更深了。"),
    ]
    close = ["这些说法，较早见于《逸周书》等文献。"]
    y = 150
    y += measure_paras(intro, f_body, TEXT_W, 58, 0) + 36
    for title, body in items:
        y += 46
        y += measure_paras([body], f_body, TEXT_W, 58, 0) + 28
    y += measure_paras(close, f_body, TEXT_W, 58, 0) + 80
    H = y
    im = vertical_gradient(H, PAPER, (236, 244, 250))
    im = add_snow(im, n=70, seed=22)
    d = ImageDraw.Draw(im)
    d.rectangle([MARGIN, 36, W - MARGIN, 37], fill=(190, 214, 230))
    d.text((MARGIN, 60), "小雪三候", font=f_h, fill=INK)
    d.rectangle([MARGIN, 118, MARGIN + 64, 122], fill=VERMILION)
    y = 150
    y = draw_paras(d, intro, MARGIN, y, TEXT_W, f_body, INK, 58, 0) + 36
    for title, body in items:
        d.ellipse([MARGIN, y + 12, MARGIN + 10, y + 22], fill=VERMILION)
        d.text((MARGIN + 24, y), title, font=f_item, fill=INK)
        y += 46
        y = draw_paras(d, [body], MARGIN + 24, y, TEXT_W - 24, f_body, INK_SOFT, 58, 0) + 28
    draw_paras(d, close, MARGIN, y, TEXT_W, f_body, INK, 58, 0)
    return im


def make_customs() -> Image.Image:
    f_h = f_serif(40)
    f_body = f_wk(30, "R")
    paras_top = [
        "小雪前后，一些地方会顺着天冷、气干，把食物慢慢收进冬天里。这些习惯因地域和物产而不同，并不是全国统一的过法。",
        "不少地方讲究「冬腊风腌，蓄以御冬」，在这前后腌制腊味，以备入冬。一些沿海地区会晾晒鱼干。南方部分地区也有打糍粑、吃糍粑的习俗，图个团圆暖意。",
    ]
    close = ["它们都是各地适应时令的生活经验，不必看成统一规矩。"]
    cured = trim_spot(ASSETS / "02-still-cured.png", 500, 420, PAPER)
    ciaba = trim_spot(ASSETS / "03-still-ciaba.png", 500, 420, PAPER)
    text_h = measure_paras(paras_top, f_body, TEXT_W, 58, 36)
    close_h = measure_paras(close, f_body, TEXT_W, 58, 0)
    img_row_h = max(cured.height, ciaba.height)
    H = 160 + text_h + 40 + img_row_h + 40 + close_h + 80
    im = vertical_gradient(H, (236, 244, 250), PAPER)
    im = add_snow(im, n=80, seed=33)
    d = ImageDraw.Draw(im)
    d.rectangle([MARGIN, 36, W - MARGIN, 37], fill=(190, 214, 230))
    d.text((MARGIN, 60), "部分地区的传统习俗", font=f_h, fill=INK)
    d.rectangle([MARGIN, 118, MARGIN + 64, 122], fill=VERMILION)
    y = draw_paras(d, paras_top, MARGIN, 150, TEXT_W, f_body, INK, 58, 36) + 36
    gap = 40
    total_w = cured.width + ciaba.width + gap
    x0 = (W - total_w) // 2
    im.paste(cured, (x0, y + (img_row_h - cured.height) // 2))
    im.paste(ciaba, (x0 + cured.width + gap, y + (img_row_h - ciaba.height) // 2))
    d = ImageDraw.Draw(im)
    y = y + img_row_h + 40
    draw_paras(d, close, MARGIN, y, TEXT_W, f_body, INK, 58, 0)
    return im


def make_closing() -> Image.Image:
    f_bless = f_serif(36)
    f_org = f_wk(26, "M")
    f_date = f_wk(22, "L")
    ending = Image.open(ASSETS / "04-ending-eaves-snow.png").convert("RGB")
    ending = scale_to_width(ending, W)
    # keep a moderate height
    target = 980
    if ending.height > target:
        # keep more of the top (sky for typography) and some eaves
        ending = ending.crop((0, 0, W, target))
    ending = fade_edges(ending, PAPER, "top", 0.22)
    ending = fade_edges(ending, SKY_DEEP if False else PAPER, "bottom", 0.08)

    # typography sits on a pale paper band above, then the ending image
    band_h = 360
    band = paper_block(band_h, PAPER)
    band = add_snow(band, n=50, seed=44)
    d = ImageDraw.Draw(band)
    d.rectangle([MARGIN, 24, W - MARGIN, 25], fill=(190, 214, 230))
    d.text((MARGIN, 64), "小雪已至，天寒岁晚。", font=f_bless, fill=INK)
    d.text((MARGIN, 122), "愿你三餐清暖，冬日安康。", font=f_bless, fill=INK)
    d.rectangle([MARGIN, 196, MARGIN + 72, 200], fill=VERMILION)
    d.text((MARGIN, 228), "苏南后勤集团", font=f_org, fill=INK)
    d.text((MARGIN, 272), "2026年11月22日 · 小雪", font=f_date, fill=INK_SOFT)

    canvas = Image.new("RGB", (W, band.height + ending.height), PAPER)
    canvas.paste(band, (0, 0))
    canvas.paste(ending, (0, band.height))
    return canvas


def main():
    require_assets()
    SEGMENTS.mkdir(exist_ok=True)
    for old in list(SEGMENTS.glob("*.jpg")) + list(SEGMENTS.glob("*.png")):
        old.unlink()

    sections = [
        ("01-cover", make_cover()),
        ("02-origin", make_origin()),
        ("03-hou", make_hou()),
        ("04-customs", make_customs()),
        ("05-closing", make_closing()),
    ]
    total = sum(s.height for _, s in sections)
    canvas = Image.new("RGB", (W, total), PAPER)
    y = 0
    for name, sec in sections:
        canvas.paste(sec, (0, y))
        y += sec.height
        sec.convert("RGB").save(SEGMENTS / f"{name}.jpg", "JPEG", quality=93, optimize=True, subsampling=0)

    preview = canvas.copy()
    preview.thumbnail((540, 30000), Image.Resampling.LANCZOS)
    preview.save(ROOT / "preview-long.jpg", "JPEG", quality=90, optimize=True)

    canvas.save(OUT_JPG, "JPEG", quality=93, optimize=True, subsampling=0)
    canvas.save(OUT_PNG, "PNG", optimize=True)

    # pack a lightweight editable source (script + article + assets), no github upload
    print(f"WROTE {OUT_JPG}  {canvas.size[0]}x{canvas.size[1]}  {OUT_JPG.stat().st_size} bytes")
    print(f"WROTE {OUT_PNG}  {canvas.size[0]}x{canvas.size[1]}  {OUT_PNG.stat().st_size} bytes")
    for name, sec in sections:
        p = SEGMENTS / f"{name}.jpg"
        print(f"  {p.name}  {sec.size[0]}x{sec.size[1]}  {p.stat().st_size}")


if __name__ == "__main__":
    main()
