# 苏南后勤集团 · 小雪节气长图（可编辑源）

成品（1080×5630）：
- `长图-苏南后勤集团-小雪节气.jpg`（建议发公众号）
- `长图-苏南后勤集团-小雪节气.png`
- `segments/` 分段预览

文案以 `ARTICLE_TEXT.txt` 为准，已核实：第二十个节气、黄经240°、三候出自《逸周书》等并标明为古人时令观察；习俗写明地域性，不是全国统一。日期为 2026年11月22日，未写农历和交节时刻。署名仅为「苏南后勤集团」文字，无虚构 logo。

重出图：

```bash
python3 compose.py
```

依赖：Python 3、Pillow、NumPy；字体为霞鹜文楷（`/home/box/.fonts/lxgw-wenkai-v1.520/`）、Noto Sans/Serif CJK、Inria Sans。插画在 `assets/`（无字），书法「小雪」为 `assets/calligraphy.jpg`。不要上传 GitHub，也不要直接发布公众号。
